<div class="navbar bg-info flex-column text-dark navbar-dark d-flex flex-column justify-content-start" >
<div class="d-flex-inline">
</div>

<ul class="navbar-nav" >
<li class="nav-item">
<a class="nav-link" href="home_a_u.php"  >
         Przeglądaj użytkowników
</a>
<li class="nav-item ">
<a class="nav-link " href="home_a_c.php"  >
         Przeglądaj klasy
</a>
</li>
</div>
</ul>
