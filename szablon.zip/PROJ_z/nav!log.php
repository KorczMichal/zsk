<nav class="navbar-expand-xl|lg|md|sm bg-info navbar-cyan sticky-top d-flex">
<div class="nav nav-item p-2 bg-dark">
  <a class="navbar-brand" href="index.php">
      <img class="logo" src="logo.png" alt="Logo" style="width: 10em;">
  </a>
</div>
<div class="nav nav-item ml-auto p-2">
  <form class="form-inline " method="post">
    <input class="form-control" type="text" name="login" value="" placeholder="Podaj login" >
    <input class="form-control" type="password" name="password" value="" placeholder="Podaj hasło">
    <button class="btn btn-success" type="submit" name="button">Zaloguj</button>
  </form>
</div>
</nav>
