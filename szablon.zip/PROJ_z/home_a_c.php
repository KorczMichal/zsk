<?php
include 'head.php';
include 'navlog.php';
include 'main_a_c.php';
include 'foot.php';
 ?>
