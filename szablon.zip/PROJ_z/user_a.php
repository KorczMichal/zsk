<?php
include 'head.php';
include 'navlog.php';
include 'main_a_u_p.php';
include 'foot.php';
 ?>
