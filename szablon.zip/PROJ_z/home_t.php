<?php
include 'head.php';
include 'navlog.php';
include 'main_t.php';
include 'foot.php';
 ?>
