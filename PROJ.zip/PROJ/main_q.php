<div class="container-fluid p-0 m-0">
  <div class="row d-flex p-0 ">
  <div class="col-2 p-1 "><?php include 'side_nav.php' ?></div>
  <div class="col-10 p-1"><?php include 'quiz.php' ?></div>
  </div>
</div>
