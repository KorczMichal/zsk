<div class="container bg-info">
  <div class=" row">
    <h4 class="col-10">Lekcja #</h4>
    <a  class="col-2 bg-dark text-center text-decoration-none text-white"href="home.php">Do lekcji</a>
  </div>
<div class="container">
  <h2 class="text-center"id="word">Słowo</h2>
  <div class="container  justify-content-center">
  <p class="text-center">Wybierz poprawne tłumaczenie:</p>
  <div class="d-flex-inline text-center">
  <button type="button" name="button">Tłumaczenie 1</button>
  <button type="button" name="button">Tłumaczenie 2</button>
  <button type="button" name="button">Tłumaczenie 3</button>
  <button type="button" name="button">Tłumaczenie 4</button>
  </div>
  <div class="row text-center" >
    <div class="col-2">
      <button class="btn btn-dark" type="button" name="button">Wstecz</button>
    </div>
    <div class="col-8">

    </div>
    <div class="col-2">
      <button class="btn btn-dark" type="button" name="button">Dalej</button>
    </div>
  </div>
  <p></p>
</div>
</div>
