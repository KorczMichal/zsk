<?php
include 'head.php';
include 'navlog.php';
include 'main.php';
include 'foot.php';
 ?>
