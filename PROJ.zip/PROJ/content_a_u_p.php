<div class="container bg-info">
<div class="container row">
  <h2 class="col-10">Panel użytkownika</h2>
  <button class="col-2" type="button" name="delete">Usuń konto</button>
</div>

<div class="bg-light" >
  <p>Typ: Uczen</p>
  <p>Status aktywne</p>
  <p>Adres e-mail: example@gmail.com</p>
</div>

</div>
