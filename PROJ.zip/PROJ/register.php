<?php
include 'head.php';
include 'register_p.php';
include 'foot.php'; ?>
