<div class="container bg-info">
<h2>Lista użytkowników</h2>
<form class="form d-flex-inline" action="" method="post">
  <input type="text" name="" value="" placeholder="Wpisz nazwę">
  <button type="submit" name="find">Znajdź</button>

</form>
<button type="button" name="student">Uczniowie</button>
<button type="button" name="teacher">Nauczyciele</button>
<div class="cotainer bg-light">
  <ul>
    <li> <a href="user_a.php">Użytkownik 1</a></li>
    <li><a href="user_a.php">Użytkownik 2</a></li>
    <li><a href="user_a.php">Użytkownik 3</a></li>
  </ul>
</div>
</div>
