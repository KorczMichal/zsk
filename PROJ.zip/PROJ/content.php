<div class="container bg-info">
<div class=" row">
  <h4 class="col-10">Lekcja #</h4>
  <a  class="col-2 bg-dark text-center text-decoration-none text-white"href="q_page.php ">Do quizu</a>
</div>
<div class="container">
  <h2 class="text-center"id="word">Słowo</h2>
  <div class="container  justify-content-center">
  <p class="text-center">Tłumaczenia:</p>
  <p class="bg-light text-center">Tłumaczenie 1, tłumaczenie 2, tłumaczenie 3</p>
  <div class="row text-center" >
    <div class="col-2">
      <button class="btn btn-dark" type="button" name="button">Wstecz</button>
    </div>
    <div class="col-8">

    </div>
    <div class="col-2">
      <button class="btn btn-dark" type="button" name="button">Dalej</button>
    </div>
  </div>
</div>
</div>
