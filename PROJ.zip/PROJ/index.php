<?php
include 'head.php';
include 'landing.php';
include 'foot.php'; ?>
