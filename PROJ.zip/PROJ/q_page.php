<?php
include 'head.php';
include 'navlog.php';
include 'main_q.php';
include 'foot.php';
 ?>
