<div class="container bg-info">
<div class="row align-content-center p-2 d-flex">
  <img class="mx-auto" src="logo.png" alt="Logo">
</div>
  <form class="form align-items-center" method="post">
    <div class="form-row flexbox col-auto p-2 m-2">
    <input class="form-control p-2" type="text" name="login" value="" placeholder="Podaj login" >
    <input class="form-control p-2" type="password" name="password" value="" placeholder="Podaj hasło">
  </div>
  <div class="text-center text-white">
    <button class="btn btn-success p-2 m-2  " type="submit" name="button"><a class="text-light" href="home.php">Zaloguj</a></button>
    <button class="btn btn-success p-2 m-2 " type="submit" name="button"><a class="text-light" href="home_t.php">Zaloguj jako nauczyciel</a></button>
    <button class="btn btn-success p-2 m-2 " type="submit" name="button"><a class="text-light" href="home_a_u.php">Zaloguj jako administrator</a></button>
      </div>
  </form>
</div>
