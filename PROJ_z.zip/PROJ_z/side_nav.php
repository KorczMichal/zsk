
<div class="navbar bg-info flex-column text-dark navbar-dark d-flex flex-column justify-content-start" >
<h4>Klasa</h4>
<ul class="navbar-nav" >
<li class="nav-item dropdown flex">
<a class="nav-link dropdown-toggle" href="#1"  data-toggle="dropdown">
         Dział 1
</a>
<div class="dropdown-menu">
        <a class="dropdown-item" href="#1">Lekcja 1</a>
        <a class="dropdown-item" href="#1">Lekcja 2</a>
        <a class="dropdown-item" href="#1">Lekcja 3</a>
      </div>
</li>
<li class="nav-item dropdown ">
<a class="nav-link dropdown-toggle" href="#2"  data-toggle="dropdown">
         Dział 2
</a>
<div class="dropdown-menu">
        <a class="dropdown-item" href="#2">Lekcja 1</a>
        <a class="dropdown-item" href="#2">Lekcja 2</a>
        <a class="dropdown-item" href="#2">Lekcja 3</a>
      </div>
</li>
</div>
</ul>
