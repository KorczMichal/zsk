<?php
include 'head.php';
include 'navlog.php';
include 'main_u_panel.php';
include 'foot.php';
 ?>
