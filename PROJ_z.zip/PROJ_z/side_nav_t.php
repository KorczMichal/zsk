<div class="navbar bg-info flex-column text-dark navbar-dark d-flex flex-column justify-content-start" >
<div class="d-flex-inline">
  <h4>Klasa</h4>
  <button type="button" name="button">Dodaj</button>
</div>

<ul class="navbar-nav" >
<li class="nav-item">
<a class="nav-link" href="#1"  data-toggle="dropdown">
         Klasa 1
</a>
<li class="nav-item ">
<a class="nav-link " href="#2"  data-toggle="dropdown">
         Klasa 2
</a>
</li>
</div>
</ul>
